package assn6;

public class Node {
	
	 String value;
	 Long idNum;
	
	public Node(String v, Long id){
		value = v;
		idNum = id;
	}
	
	
	
	

}
